package com.modus.projectmanagement.exception;

public class ProjectCreationException extends RuntimeException{
public ProjectCreationException(String message){
super(message);
}
}
