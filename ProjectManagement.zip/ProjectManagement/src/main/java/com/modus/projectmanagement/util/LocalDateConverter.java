package com.modus.projectmanagement.util;
import com.opencsv.bean.AbstractBeanField;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

public class LocalDateConverter extends AbstractBeanField<LocalDate, String> {
    private static final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    @Override
    protected LocalDate convert(String value) {
        try {
            return LocalDate.parse(value, formatter);
        } catch (DateTimeParseException e) {
            throw new RuntimeException("Invalid date format: " + value, e);
        }
    }
}
