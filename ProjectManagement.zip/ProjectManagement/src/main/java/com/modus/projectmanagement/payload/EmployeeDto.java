package com.modus.projectmanagement.payload;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.modus.projectmanagement.util.LocalDateConverter;
import com.opencsv.bean.CsvBindByName;
import com.opencsv.bean.CsvCustomBindByName;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.jpa.convert.threeten.Jsr310JpaConverters;

import java.math.BigDecimal;
import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class EmployeeDto {
    @NotNull(message = "{EMPLOYEE_ID_NULL}")
    @CsvBindByName(column = "empId")
    private Long empId;

    @NotBlank(message = "{EMPLOYEE_NAME_REQUIRED}")
    @Size(min = 2, max = 50, message = "{EMPLOYEE_NAME_SIZE}")
    @CsvBindByName(column = "empName")
    private String empName;

    @NotBlank(message = "{EMPLOYEE_PHONE_REQUIRED}")
    @Pattern(regexp = "\\d{10}", message = "{EMPLOYEE_PHONE_INVALID}")
    @CsvBindByName(column = "phone")
    private String phone;

    @NotBlank(message = "{EMPLOYEE_EMAIL_REQUIRED}")
    @Email(message = "{EMPLOYEE_EMAIL_INVALID}")
    @CsvBindByName(column = "email")
    private String email;

    @NotBlank(message = "{EMPLOYEE_DESIGNATION_REQUIRED}")
    @CsvBindByName(column = "designation")
    private String designation;

    @NotNull(message = "{EMPLOYEE_SALARY_REQUIRED}")
    @CsvBindByName(column = "salary")
    private String salary;

    @NotBlank(message = "{EMPLOYEE_LOCATION_REQUIRED}")
    @CsvBindByName(column = "location")
    private String location;

//    @NotBlank(message = "{EMPLOYEE_JOINING_DATE_REQUIRED}")
//    @Pattern(regexp = "\\d{4}-\\d{2}-\\d{2}", message = "{EMPLOYEE_JOINING_DATE_INVALID}")
//    private String joiningDate;
    @NotNull(message = "{EMPLOYEE_JOINING_DATE_REQUIRED}")
    @JsonFormat(pattern = "yyyy-MM-dd")
    @CsvCustomBindByName(column = "joiningDate", converter = LocalDateConverter.class)
    private LocalDate joiningDate;
}
