package com.modus.projectmanagement.service;
import com.modus.projectmanagement.payload.ManagerDto;
public interface ManagerService {
    public ManagerDto addManager(ManagerDto managerDto);
}
