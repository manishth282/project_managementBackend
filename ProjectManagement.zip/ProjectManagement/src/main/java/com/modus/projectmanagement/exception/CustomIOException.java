package com.modus.projectmanagement.exception;

public class CustomIOException extends RuntimeException{

    public CustomIOException(String message){super(message);}

}
